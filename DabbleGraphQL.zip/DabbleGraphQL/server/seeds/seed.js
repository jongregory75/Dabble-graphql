const db = require("../config/connection");
const AlbaniaModel = require("../models");
const countryData = require("./countryData.json");

db.once("open", async () => {
  //delete previous collection
  await AlbaniaModel.deleteMany();

  //insert into DB data from JSON
  const albaniaData = await AlbaniaModel.insertMany(countryData);

  albaniaData
    ? console.log("albaniaData seeded!")
    : console.log("albaniaData error!");

  process.exit(0);
});
