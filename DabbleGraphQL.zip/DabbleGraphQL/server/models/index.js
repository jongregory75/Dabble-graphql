const AlbaniaModel = require("./AlbaniaModel");

module.exports = { AlbaniaModel };
