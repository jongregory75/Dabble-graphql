const { gql } = require("apollo-server-express");

const typeDefs = gql`
  type AlbaniaModel {
    country: String
    year: String
    areaKm: String
    totalPopulation: String
  }
  type Query {
    allAlbaniaData: [AlbaniaModel]
  }
`;

module.exports = typeDefs;
