const { AlbaniaModel } = require("../models");

const resolvers = {
  Query: {
    allAlbaniaData: async () => {
      return await AlbaniaModel.find({});
    },
  },
};

module.exports = resolvers;

// count_by_id: async (parent, { _id }) => {
//   console.log("Country by ID Resolver");
//   return await AlbaniaModel.find({ _id }).populate("count_by_id");
// },
